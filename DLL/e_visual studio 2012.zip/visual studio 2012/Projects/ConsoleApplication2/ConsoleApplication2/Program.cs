﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace ConsoleApplication2
{
    class Program
    {
        [DllImport("e:\\visual studio 2012\\Projects\\ConsoleApplication3\\Debug\\ConsoleApplication3.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Add(double x);//, double y);

        static void Main(string[] args)
        {
            double a = 2, b = 5;
            double aa = Add(a);//, b);
            Console.Write(aa);
        }
    }
}
