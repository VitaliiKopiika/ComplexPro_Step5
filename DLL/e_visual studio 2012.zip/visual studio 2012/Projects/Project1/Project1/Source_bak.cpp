// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include <iostream>

using namespace std;

void qqq ( int *p_arr, int size_x, int size_y = 1, int size_z = 1);
#define arr(ptr) ((int *)ptr)

void main()
{
	const int size_x = 4, size_y = 4, size_z = 4;

	int arr1[size_x];
	int arr2[size_x][size_y];
	int arr3[size_x][size_y][size_z];
	
	qqq (     arr1 , size_x);
	qqq ( arr(arr2), size_x, size_y);
	qqq ( arr(arr3), size_x, size_y, size_z);

		cout << endl << endl;

system("pause");

	return ;
}



void qqq ( int *p_arr, int size_x, int size_y, int size_z)
{
	int sum = 1;	

	for (int x = 0 ; x < size_x ; x++)
		for (int y = 0 ; y < size_y ; y++)
			for (int z = 0 ; z < size_z ; z++)   p_arr[x*size_y*size_z + y*size_z + z] = sum++;


	for (int x = 0 ; x < size_x ; x++)
	{
		for (int y = 0 ; y < size_y ; y++)
		{
			if ( size_z > 1)
			{
				cout << endl;
				for (int t = 0 ; t < y ; t++)   cout << "   ";
			}

			for (int z = 0 ; z < size_z ; z++)   cout << p_arr[x*size_y*size_z + y*size_z + z] << "  ";
		}

		if ( size_y > 1)	cout << endl;
	}

}