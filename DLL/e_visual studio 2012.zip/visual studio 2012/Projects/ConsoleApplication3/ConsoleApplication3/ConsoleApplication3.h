// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the CONSOLEAPPLICATION3_EXPORTS
// symbol defined on the command line. This symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// CONSOLEAPPLICATION3_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef CONSOLEAPPLICATION3_EXPORTS
#define CONSOLEAPPLICATION3_API __declspec(dllexport)
#else
#define CONSOLEAPPLICATION3_API __declspec(dllimport)
#endif

// This class is exported from the ConsoleApplication3.dll
class CONSOLEAPPLICATION3_API CConsoleApplication3 {
public:
	CConsoleApplication3(void);
	// TODO: add your methods here.
};

extern CONSOLEAPPLICATION3_API int nConsoleApplication3;

CONSOLEAPPLICATION3_API int fnConsoleApplication3(void);
