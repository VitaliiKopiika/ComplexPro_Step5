#pragma once

class Sumx
{
public:
	double Add( double x);//, double y);

};

double Sumx::Add( double x)//, double y)
{
	return x ;//x+y;
}

extern "C" __declspec(dllexport) double Add( double x)//, double y)
{
	Sumx SM;
	return SM.Add(x);//,y);
}