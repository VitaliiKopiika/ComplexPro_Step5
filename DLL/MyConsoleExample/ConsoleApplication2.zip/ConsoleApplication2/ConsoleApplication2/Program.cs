﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace ConsoleApplication2
{
        //public static extern void FasterFunction(
        //[MarshalAs(UnmanagedType.LPArray)]ushort[] inImage, //IntPtr inImage, 
        //[MarshalAs(UnmanagedType.LPArray)]byte[] outImage, //IntPtr outImage, 
        //int inTotalSize, int inWindow, int inLevel);


    class Program
    {
        [DllImport("e:\\visual studio 2012\\Projects\\ConsoleApplication3\\Debug\\ConsoleApplication3.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Add(double x);//, double y);

        [DllImport("e:\\visual studio 2012\\Projects\\ConsoleApplication3\\Debug\\ConsoleApplication3.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void Print([MarshalAs(UnmanagedType.LPStr)]String msg);

        [DllImport("e:\\visual studio 2012\\Projects\\ConsoleApplication3\\Debug\\ConsoleApplication3.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void PrintArr([MarshalAs(UnmanagedType.LPArray)]char[] msg, int size);

        static void Main(string[] args)
        {
            double a = 2, b = 5;
            double aa = Add(a);//, b);
            Console.Write(aa);

            char[] str = new char[] {'q', 's','d','g' };

            Print("1234567");

            PrintArr(str, str.Length);

            Console.ReadKey();
        }
    }
}


