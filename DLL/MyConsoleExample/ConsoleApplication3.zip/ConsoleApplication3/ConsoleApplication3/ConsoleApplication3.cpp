// ConsoleApplication3.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "ConsoleApplication3.h"
#include <iostream>
using namespace std;
//
//// This is an example of an exported variable
//CONSOLEAPPLICATION3_API int nConsoleApplication3=0;
//
//// This is an example of an exported function.
//CONSOLEAPPLICATION3_API int fnConsoleApplication3(void)
//{
//	return 42;
//}
//
//// This is the constructor of a class that has been exported.
//// see ConsoleApplication3.h for the class definition
//CConsoleApplication3::CConsoleApplication3()
//{
//	return;
//}

#pragma once

class Sumx
{
public:
	double Add( double x);//, double y);
	void Print(char* qqq)
	{
		cout << "\n\n" << qqq << "\n\n";
	}

	void PrintArr(char arr[], int size)
	{
		cout << "\n\n";
		for ( int i = 0 ; i < size; i++)	cout << arr[i];
	}
};

double Sumx::Add( double x)//, double y)
{
	return x ;//x+y;
}
//------------------


extern "C" __declspec(dllexport) double Add( double x)//, double y)
{
	Sumx SM;
	return SM.Add(x);//,y);
}

extern "C" __declspec(dllexport) void Print( char* qqq)
{
	Sumx SM;
	SM.Print(qqq);
	return;
}

extern "C" __declspec(dllexport) void PrintArr( char qqq[], int size)
{
	Sumx SM;
	SM.PrintArr(qqq, size);
	return;
}